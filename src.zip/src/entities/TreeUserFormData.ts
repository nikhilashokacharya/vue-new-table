import { UserForm } from './UserForm';

export interface TreeUserFormData {
  name: string,
  VBAProject1: {
    userFormCount: number,
    ID_USERFORM1: UserForm
  }
}