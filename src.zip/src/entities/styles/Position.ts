export interface Position {
    position:string
}