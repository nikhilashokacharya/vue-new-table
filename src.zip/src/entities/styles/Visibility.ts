export interface Visibility {
    backColor: string,
    backStyle: string,
    borderColor: string,
   /*  borderStyle: string, */
    font: string,
    textAlign: string,
    foreColor: string,
    mousePointer: string,
    specialEffect: string,
   /*  pictureSizeMode: string,
    pictureTiling: string,
    picturePosition: string, 
    picture: string,*/


}