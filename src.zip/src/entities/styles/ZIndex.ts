export default interface ZIndex {
    zIndex: string,
}