export const treeData = {
  name: "VBA Project(Book1)",
  VBAProject1: {
    userFormCount:0,
    ID_USERFORM1: {
      elementsCount:{
        label:0,
        commandButton:0
      },
      property: {
        zIndex: "",
        position: "relative",
        textAlign: "left",
        border: "none",
        width: "400px",
        height: "250px",
        resize: "both",
        overflow: "hidden",
        borderTopLeftRadius: "4px",
        borderTopRightRadius: "4px",
        maxWidth: "98%",
        maxHeight: "88%",
        margin: "4px",
        backColor: "white",
        borderColor: "ghostwhite",
        font: "Tahoma",
        foreColor: "black",
        left: "0",
        top: "0",
        zoom: "100%",
        mousePointer: "0 - fmMousePointerDefault",
        specialEffect: "none",
        pictureSizeMode: " 9px 10px",
        picture: "radial-gradient(circle, rgb(0, 0, 0) 0.5px, rgba(0, 0, 0, 0) 0.2px)",
        controlZIndex: 3,
        name: "UserForm1",
        type: "UserForm",
        visible: true,
        autoSize: false,
        isActive: false,
        caption: "UserForm1",
        cycle: "0 - fmCycleAllForms",
        drawBuffer: 32000,
        enabled: true,
        helpContextId: 0,
        keepScrollsBarsVisible: "fmScrollBarsNone",
        mouseIcon: "(None)",
        pictureAlignment: "0 - fmPictureAlignmentTopLeft",
        pictureTiling: false,
        rightToLeft: false,
        scrollBars: "0 - fmScrollBarsNone",
        scrollHeight: 0,
        scrollLeft: 0,
        scrollTop: 0,
        startUpPosition: "0 - Manual",
        scrollWidth: 0,
        showModal: true,
        tag: "",
        whatsThisButton: false,
        whatsThisHelp: false,
        display: "block",
        outerWindowZIndex: "2",
        outerWindowtop: "50px",
        outerWindowleft: "50px",
      },
      controls:{
        ID_LABEL1:{
          name:"Label1",
          tabindex:0
        },
        ID_COMMANDBUTTON1:{
          name:"CommandButton1",
          tabindex:1
        },
        ID_TEXTBOX1:{
          name:"TextBox1",
          tabindex:2
        }
      },
     

    },
    
  }
}