declare module '*.vue' {
  import Vue from 'vue'
  export default  Vue

}

declare module 'vue-draggable-resizable'
declare module 'vue-element-resize-detector'
declare module 'vue-resizable'
declare module 'vue-context-menu'
declare module 'vue-split-panel'
declare module 'validator.js'