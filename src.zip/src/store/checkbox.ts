import { GetterTree, MutationTree, ActionTree } from 'vuex'
import { CheckBox } from "@/entities/CheckBox";
import { CheckBox as checkbox } from "@/models/CheckBox";

export const state: CheckBox=checkbox;
