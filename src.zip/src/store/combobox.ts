import { ComboBox } from "@/entities/ComboBox";
import { ComboBox as combox } from "@/models/ComboBox";

export const state: ComboBox=combox;

