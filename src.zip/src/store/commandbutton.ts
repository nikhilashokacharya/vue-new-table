import { CommandButton } from "@/entities/CommandButton";
import { CommandButton as commandButton} from "@/models/CommandButton";

export const state : CommandButton=commandButton;