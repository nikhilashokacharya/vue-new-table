import { Frame } from "@/entities/Frame";
import { Frame as frame } from "@/models/Frame";

export const state : Frame=frame;