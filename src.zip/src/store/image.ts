import { Image } from "@/entities/Image";
import { Image as image } from "@/models/Image";

export const state : Image = image;