import { Label } from "@/entities/Label";
import { Label as label } from "@/models/Label";

export const state : Label = label;