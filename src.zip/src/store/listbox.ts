import { ListBox } from "@/entities/ListBox";
import { ListBox as listbox } from "@/models/ListBox";

export const state : ListBox = listbox;