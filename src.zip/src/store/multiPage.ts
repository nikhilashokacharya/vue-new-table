import { GetterTree, MutationTree, ActionTree } from 'vuex'
import { MultiPage } from "@/entities/MultiPage";
import { MultiPage as multiPage } from "@/models/MultiPage";

export const state: MultiPage=multiPage;
