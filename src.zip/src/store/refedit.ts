import { GetterTree, MutationTree, ActionTree } from 'vuex'
import { RefEdit } from "@/entities/RefEdit";
import { RefEdit as refEdit } from "@/models/RefEdit";

export const state: RefEdit = refEdit;
