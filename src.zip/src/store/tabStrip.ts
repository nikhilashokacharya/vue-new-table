import { GetterTree, MutationTree, ActionTree } from 'vuex'
import { TabStrip } from "@/entities/TabStrip";
import { TabStrip as tabStrip } from "@/models/TabStrip";

export const state: TabStrip = tabStrip;
