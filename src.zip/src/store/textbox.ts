import { TextBox } from "@/entities/TextBox";
import { TextBox as textbox } from "@/models/TextBox";

export const state : TextBox = textbox