import { ToggleButton } from "@/entities/ToggleButton";
import { ToggleButton  as togglebutton } from "@/models/ToggleButton";

export const state : ToggleButton = togglebutton;